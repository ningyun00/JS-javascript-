$(function () {
    $("#shopping_commend_arrow").click(function () {
        $(this)..parent().parent().next().hide();
    });
});